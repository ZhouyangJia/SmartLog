#define PATH_BFTPD_CONF "/etc/bftpd.conf"
#define PATH_STATUSLOG "/dev/null"
